package lecture07;

public class insertDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
