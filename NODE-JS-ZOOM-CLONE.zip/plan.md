# Plan Of Action

- Initialize our NodeJS Project DONE
- Initialize our first view DONE
- Create a room id DONE
- Add the ability to view our own Video DONE
- Add ability to allow others to stream their video
- Add styling
- Add the ability to create messages
- Add Stop Video button